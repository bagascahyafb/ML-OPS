from pycaret.classification import *
import streamlit as st
import pandas as pd
import numpy as np

#load pretrained model for classification
model = load_model('happiness_pipeline')

#define classification function to scall
def predict(model, input_df):
    try:
        predictions_df = predict_model(model, data=input_df)
        predictions = predictions_df['prediction_label'][0]
        return predictions
    except KeyError as e:
        st.error(f"Error: {e}. Please check the column names in your input data.")

def run():
    #mengambil gambar yang ada difolder
    from PIL import Image
    image = Image.open('images/logo_sdt.png')
    image_happy = Image.open('images/happy.jpg')
    happy_result = Image.open('images/happyresult.jpg')
    sad_result = Image.open('images/sadresult.jpg')

    #add sidebar to the app
    st.sidebar.image(image)
    st.sidebar.title('Demo ML-OPS Week 9')
    st.sidebar.markdown("An app that predicts or classifies whether you're happy or not using Pycaret's classification")
    st.sidebar.info("This application only aims to demo ML-OPS courses without expert assistance, so the results of predictions are not accurate")
    st.sidebar.success("By: Bagas Cahya Fajar Bastian")
    
    #add title and subtitle to the main interface of the app
    st.image(image_happy, width=750)
    st.title("Are You Happy or Not? Lets Find Out!")
    st.markdown("This website provide you some basic prediction about you are happy or not.")
    infoavail = st.radio('How information about your city service is available', [1,2,3,4,5], horizontal=True)
    housecost = st.radio('Are the prices of houses in your place affordable', [1,2,3,4,5], horizontal=True)
    schoolquality = st.radio('How is the quality of the school in your place', [1,2,3,4,5], horizontal=True)
    policetrust = st.radio('your trust in the local police', [1,2,3,4,5], horizontal=True)
    streetquality = st.radio('How is maintenance of streets and sidewalks in your place', [1,2,3,4,5], horizontal=True)
    ëvents  = st.radio('Are there many useful events in your place', [1,2,3,4,5], horizontal=True)

    input_dict = {'infoavail': int(infoavail),
                'housecost': int(housecost),
                'schoolquality': int(schoolquality),
                'policetrust': int(policetrust),
                'streetquality': int(streetquality),
                'ëvents': int(ëvents)
                }

    input_df = pd.DataFrame([input_dict])
    if st.button("Predict"):
        output = predict(model=model, input_df=input_df)
        if output:
            st.success('You are Happy Person')
            st.image(happy_result, width=700)
            st.markdown('Lets spread this happiness with everyone')
        else:
            st.error('You are Sad:(')
            st.image(sad_result, width=700)
            st.markdown('Dont worry, there will definitely be happiness tomorrow')

if __name__ == '__main__':
    run()